if ($('#msform').length) {

    odoo.define('lapalma_website.shipment_form', function (require) {
        "use strict";

    });
}

