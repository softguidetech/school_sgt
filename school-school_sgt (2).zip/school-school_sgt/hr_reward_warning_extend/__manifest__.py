# -*- coding: utf-8 -*-
{
    'name': 'Open HRMS Official Announcements Extend',
    'version': '16.0.1.0.0',
    'summary': """Announcements Notifications""",
    'description': 'This module helps you to manage hr official announcements Notifications',
    'author': 'Jamsheena kc',
    'company': 'SGT',
    'website': 'https://softguidetech.com',
    'depends': ['hr_reward_warning', 'mail'],
    'data': [
        'data/mail_template.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
