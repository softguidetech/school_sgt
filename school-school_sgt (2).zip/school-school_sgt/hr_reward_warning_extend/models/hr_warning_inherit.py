# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class HrAnnouncementTable(models.Model):
    _inherit = 'hr.announcement'
    _description = 'HR Announcement'

    def send_approval_email(self):
        template_id = self.env.ref('hr_reward_warning_extend.approved_email_template')
        for announcement in self:
            if announcement.state == 'approved':
                employee_emails = [employee.work_email for employee in announcement.employee_ids]
                if template_id and employee_emails:
                    # template_id.write({'email_to': ','.join(employee_emails)})
                    template_id.sudo().send_mail(announcement.id, force_send=False)
    def approve(self):
        super(HrAnnouncementTable, self).approve()
        self.send_approval_email()