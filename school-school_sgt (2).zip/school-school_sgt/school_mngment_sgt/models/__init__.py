# -*- coding: utf-8 -*-

from . import school
from . import student
from . import teacher
from . import parent
from . import res_users
from . import account
from . import library_editor_supplier
from . import library
from . import product
from . import stock
from . import transport
from . import homework
from . import school_fees
from . import timetable
from . import event
from . import school_evaluation
from . import school_attendance
from . import exam

