# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to School Management System
# ----------------------------------------------------------
from . import test_school
from . import test_library
from . import test_transport
from . import test_assignment
from . import test_fees
from . import test_timetable
from . import test_event
from . import test_evaluation
from . import test_attendance
from . import test_exam


