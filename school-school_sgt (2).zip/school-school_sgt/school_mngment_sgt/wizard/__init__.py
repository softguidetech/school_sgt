# See LICENSE file for full copyright and licensing details.

from . import assign_roll_no
from . import move_standards
from . import teriminate_reason
from . import terminate_reason
from . import transfer_vehicle
from . import trnsport_terminate_reason
from . import reason
from . import assignment_terminate_reason
from . import payslip_terminate_reason
from . import event_terminate_reason
from . import evaluation_terminate_reason
from . import attendance_sheet_wizard
from . import student_attendance_by_month
from . import monthly_attendance_wizard
from . import exam_move_standards
from . import batch_result
from . import exam_terminate_reason
from . import exam_subject_result
