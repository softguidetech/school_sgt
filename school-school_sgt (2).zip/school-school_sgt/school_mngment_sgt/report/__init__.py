# See LICENSE file for full copyright and licensing details.

from . import report_student_fees_register
from . import report_student_payslip
from . import timetable_info
from . import attendance_by_month_student
from . import month_attendance_report
from . import batch_result_report
from . import result_info
from . import exam_result
