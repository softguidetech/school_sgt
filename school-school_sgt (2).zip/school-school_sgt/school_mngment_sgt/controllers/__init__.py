# -*- coding: utf-8 -*-

from . import assignment_portal
from . import payslip_portal
from . import timetable_portal
from . import exam_timetable_portal
from . import event_portal
from . import student_evaluation
