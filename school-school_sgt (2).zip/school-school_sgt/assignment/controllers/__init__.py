# -*- coding: utf-8 -*-

from . import assignment_portal
